#import <Foundation/Foundation.h>

@interface NFLogger : NSObject {
    NSString *_path;
}

- (id)initWithPath:(NSString *)path;
- (void)write:(NSString *)text;
- (void)dealloc;

@end
