// Umbrella header for NekokawaFoundation.
// Add import lines for each public header, like this: #import <NekokawaFoundation/XXXAwesomeClass.h>
// Don’t forget to also add them to NekokawaFoundation_PUBLIC_HEADERS in your Makefile!

#import <NekokawaFoundation/NFLogger.h>
#import <NekokawaFoundation/NFDefaults.h>
