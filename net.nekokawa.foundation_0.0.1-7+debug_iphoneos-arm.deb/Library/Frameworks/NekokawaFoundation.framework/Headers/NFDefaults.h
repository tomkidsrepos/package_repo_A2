#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>

@interface NFDefaults : NSObject {
    CFStringRef _bundleID;
}

- (id)initWithBundleID:(NSString *)bundleID;
- (BOOL)boolWithKey:(NSString *)keyString default:(BOOL)defaultValue;
- (int)intWithKey:(NSString *)keyString default:(int)defaultValue;
- (NSString *)stringWithKey:(NSString *)keyString default:(NSString *)defaultValue;
- (void)dealloc;

@end
